﻿using System;
namespace labWork
{
internal class Arr
    {
        
        static void Main() 
        {
            int[][] arr= new int[3][];//no. of batches=3
            arr[0] = new int[3];//batch 1 have 3 students
            arr[1]= new int[2];//batch 2 have 2 students
            arr[2]= new int[2];//batch 3 have 2 students
            for(int i=0; i<arr.Length;i++)
            {
                for(int j = 0; j <arr[i].Length;j++)
                {
                    Console.WriteLine("enter marks for batch {0} and student {1} : ", i+1, j+1 );
                    arr[i][j] = Convert.ToInt32(Console.ReadLine());
                }

            }
            Console.WriteLine();
            for (int i = 0; i < arr.Length; i++)
            {
                
                Console.WriteLine("_______________");
                Console.WriteLine("Marks for batch : " + (i+1));
                
                for (int j = 0; j < arr[i].Length; j++)
                {
                    Console.WriteLine("marks of student {0} is {1}",j+1, arr[i][j]);
                }
            }
            Console.ReadLine();
        }

    }
    }
  




    