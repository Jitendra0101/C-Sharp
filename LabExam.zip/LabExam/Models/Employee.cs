﻿using Microsoft.CodeAnalysis.Completion;
using Microsoft.Data.SqlClient;
using System.ComponentModel.DataAnnotations;
using System.Data;

namespace LabExam.Models
{
    public class Employee
    {
        [ScaffoldColumn(false)]
        public int Id { get; set; }

        [Required(ErrorMessage = "Please enter employee name.")]
        public string? Name { get; set; }
        [Required(ErrorMessage = "Please enter employee city.")]
        public string? City { get; set; }
        [Required(ErrorMessage = "Please enter employee address.")]
        public string? Address { get; set; }

        public Employee() { }
        public Employee(int id, string name, string city, string addr)
        {
            this.Id = id;
            this.Name = name;
            this.City = city;
            this.Address = addr;
        }
        public static List<Employee?>? getAllEmployees()
        {

            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=LabExam;Integrated Security=True;Connect Timeout=30;Encrypt=False;Trust Server Certificate=False;Application Intent=ReadWrite;Multi Subnet Failover=False";

            try
            {
                cn.Open();

                List<Employee?> list = new List<Employee?>();
                SqlCommand cmdSelect = new SqlCommand();
                cmdSelect.Connection = cn;
                cmdSelect.CommandType = CommandType.Text;
                cmdSelect.CommandText = "SELECT * FROM Employees";

                using (SqlDataReader reader = cmdSelect.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        int id = reader.GetInt32("Id");
                        string name = reader.GetString("Name");
                        string city = reader.GetString("City");
                        string addr = reader.GetString("Address");

                        Employee emp = new Employee(id, name, city, addr);

                        list.Add(emp);

                    }
                    return list;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return null;
            }
            finally { cn.Close(); }
        }

        public static Employee getEmployee(int id)
        {

            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=LabExam;Integrated Security=True;Connect Timeout=30;Encrypt=False;Trust Server Certificate=False;Application Intent=ReadWrite;Multi Subnet Failover=False";

            try
            {
                cn.Open();

                SqlCommand cmdSelect = new SqlCommand();
                cmdSelect.Connection = cn;
                cmdSelect.CommandType = CommandType.Text;
                cmdSelect.CommandText = "SELECT * FROM Employees WHERE Id = @id";
                cmdSelect.Parameters.AddWithValue("@id", id);

                using (SqlDataReader reader = cmdSelect.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        int empId = reader.GetInt32("Id");
                        string name = reader.GetString("Name");
                        string city = reader.GetString("City");
                        string addr = reader.GetString("Address");



                        Employee emp = new Employee(empId, name, city, addr);
                        return emp;
                    }
                    else
                    {
                        return null;
                    }
                }
            }

            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return null;
            }

            finally
            {
                cn.Close();
            }


        }

        public static void updateAll(Employee emp)
        {
            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=LabExam;Integrated Security=True;Connect Timeout=30;Encrypt=False;Trust Server Certificate=False;Application Intent=ReadWrite;Multi Subnet Failover=False";

            try
            {
                cn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = cn;
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "UPDATE Employees SET Name = @empName, City = @city , Address = @addr WHERE Id = @id";
                cmd.Parameters.AddWithValue("@empName", emp.Name);
                cmd.Parameters.AddWithValue("@city", emp.City);
                cmd.Parameters.AddWithValue("@addr", emp.Address);
                cmd.Parameters.AddWithValue("@id", emp.Id);

                int result = cmd.ExecuteNonQuery();

                if (result > 0)
                {
                    Console.WriteLine("Row updation successful !!");
                }
                else
                { Console.WriteLine("Failed to Update table !!"); }

            }
            catch (Exception ex) { Console.WriteLine(ex.Message); }

            finally { cn.Close(); }
        }

    }
}
