﻿
namespace day_2_assign 
{ 
public class Employee
{
    private string name;
    public String Name
    {
        get 
        { 
            return name; 
        }
        set 
        {
                if(value == "")
                {
                    Console.WriteLine("Invalid Name !!!");
                }
                else
                {
                    name = value;
                }
        }

    }
    private int empNo;
    public int EmpNo
    {
        get
        {
            return empNo;
        }
        set
        {
          if(value<=0)
            {
                Console.WriteLine("Invalid EmpNo");
            }
          else
            {
                empNo = value;
            }
        }
    }
    private decimal basic;
    public decimal Basic
    {
        get
        {
                return basic;
        }
        set
        {
            if (value>=100000 && value <= 200000)
            {
                basic = value;
            }

            else
            {
                Console.WriteLine("Invalid range of salary !!");
            }
        }
    }

    private short deptNo;
    public short DeptNo
    {
        get
        {
            return deptNo;
        }
        set
        {
            if (value <= 0)
            {
                Console.WriteLine("Invalid DeptNo");
            }
            else
            {
                deptNo = value;
            }
        }
    }

    public decimal GetNetSalary()
    {
        return ((12 * basic) - 12000);
    }

    public Employee(int empNo, String name, decimal basic, short deptNo)
    {
        this.empNo = empNo;
        this.basic = basic;
        this.name = name;
        this.deptNo = deptNo;
    }
    public Employee(int empNo, String name, decimal basic)
    {
        this.empNo = empNo;
        this.name = name;
        this.basic = basic;
    }
    public Employee(int empNo, String name)
    {
        this.empNo = empNo;
        this.name = name;
    }
    public Employee(int empNo)
    {
        this.empNo = empNo;
    }

    public Employee()
    {
        Console.WriteLine("no param constr called");
    }

        static void Main()
        {
            Employee o1 = new Employee(1, "Amol", 123465, 10);
            Employee o2 = new Employee(1, "Amol", 123465);
            Employee o3 = new Employee(1, "Amol");
            Employee o4 = new Employee(1);
            Employee o5 = new Employee();


            /*Console.WriteLine(o1.basic);
            Console.WriteLine(o2.name);
            Console.WriteLine(o3.name);
            Console.WriteLine(o4.name);
            Console.WriteLine(o5.name);*/

            o1.Basic = 1;

        }
    }

}